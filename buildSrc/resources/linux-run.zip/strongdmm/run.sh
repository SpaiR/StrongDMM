#!/bin/bash
./runtime/bin/java -Xmx500m -Dsdmmparser.path=./lib -jar ./lib/strongdmm.jar
exit
